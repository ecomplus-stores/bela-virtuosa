window.ECOM_CONFIG = {
  default_img_size: 'big'
}
